package com.assignment.paymentmanagementservice.util;

import com.assignment.paymentmanagementservice.constants.ErrorMessages;
import com.assignment.paymentmanagementservice.constants.OrderStatus;
import com.assignment.paymentmanagementservice.constants.PaymentStatus;
import com.assignment.paymentmanagementservice.dto.OrderDto;
import com.assignment.paymentmanagementservice.entities.Order;
import com.assignment.paymentmanagementservice.entities.Payment;
import com.assignment.paymentmanagementservice.exceptions.CustomGenericException;
import com.assignment.paymentmanagementservice.payloads.PaymentResponse;
import com.assignment.paymentmanagementservice.repositories.CustomerRepo;
import com.assignment.paymentmanagementservice.repositories.OrderRepo;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@FieldDefaults(level = AccessLevel.PRIVATE)
@Configuration
public class Validations {
    @Autowired
    OrderRepo orderRepo;
    @Autowired
    CustomerRepo customerRepo;

    public void validateOrder(OrderDto order) {
        if (order.getStatus() != OrderStatus.PENDING) {
            throw new CustomGenericException(ErrorMessages.FORBIDDEN_CODE, ErrorMessages.CANNOT_PASS_STATUS);
        }
        if (order.getPaymentMode() == null) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.SELECT_PAYMENT_MODE);
        }

    }

    public void validateNewOrder(OrderDto order) {
        if (order.getCustomer() == null) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.ENTER_CUSTOMER_DETAILS);
        }
    }

    public void validateExistingcustomer(OrderDto order) {
        if (order.getCustomer().getName() == null) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.PHONE_NUMBER_NOT_EXISTS_ERROR);
        }
    }

    public void validateExistingOrder(OrderDto order) {
        if (!orderRepo.existsByOrderId(order.getOrderId())) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.NO_ORDER_FOUND);

        }
    }

    public void validateAmountForExistingOrder(OrderDto order, OrderDto existingOrder) {
        if (order.getAmount() != null && !existingOrder.getAmount().equals(order.getAmount())) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.AMOUNT_CANNOT_BE_CHANGED);
        }
    }

    public void validateOrders(List<Order> orders, String errorMessage) {
        if (orders.isEmpty()) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, errorMessage);
        }
    }

    public void validateOrderExists(Order order) {
        if (order == null) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.NO_ORDER_FOUND);
        }
    }

    public void validateCustomer(long id) {
        if (!customerRepo.findById(id).isPresent()) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.NO_CUSTOMER_FOUND);
        }

    }

    public void validateListOfPayments(List<PaymentResponse> lst) {
        if (lst.isEmpty()) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.NO_TRANSACTIONS_FOUND);
        }
    }

    public void validatePayments(Payment payment) {
        if (payment == null) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.NO_PAYMENT_WITH_TRANSACTIONID);
        }
        if (payment.getOrder().getStatus() == OrderStatus.ORDER_CONFIRMED) {
            throw new CustomGenericException(ErrorMessages.BAD_REQUEST_CODE, ErrorMessages.ORDER_ALREADY_CONFIRMED);
        }
    }

    public void validatePaymentStatus(PaymentStatus currentStatus) {
        if (currentStatus.ordinal() >= PaymentStatus.SUCCESS.ordinal()) {
            throw new CustomGenericException(ErrorMessages.FORBIDDEN_CODE, ErrorMessages.PAYMENT_STATUS_FORBIDDEN);
        }
    }
}
