package com.assignment.paymentmanagementservice.batch.configurations;


import com.assignment.paymentmanagementservice.batch.processors.StatusProcessor;
import com.assignment.paymentmanagementservice.entities.Payment;
import com.assignment.paymentmanagementservice.repositories.PaymentRepo;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import java.io.File;

@EnableBatchProcessing
@Configuration
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequiredArgsConstructor
public class PaymentStatusUpdateBatch {
    JobBuilderFactory jobBuilderFactory;
    StepBuilderFactory stepBuilderFactory;
    PaymentRepo paymentRepo;


    @Bean
    @StepScope
    public FlatFileItemReader<Payment> reader4(@Value("#{jobParameters[filename]}") String pathToFile) {
        FlatFileItemReader<Payment> itemReader = new FlatFileItemReader<>();

        itemReader.setResource(new FileSystemResource(new File(pathToFile)));
        itemReader.setName("CsvReader");
        itemReader.setLinesToSkip(1);
        itemReader.setLineMapper(lineMapper());

        return itemReader;
    }

    public LineMapper<Payment> lineMapper() {
        DefaultLineMapper<Payment> lineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer delimitedLineTokenizer = new DelimitedLineTokenizer();
        delimitedLineTokenizer.setDelimiter(",");
        delimitedLineTokenizer.setStrict(false);
        delimitedLineTokenizer.setNames("transactionId", "status");
        BeanWrapperFieldSetMapper<Payment> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(Payment.class);
        lineMapper.setLineTokenizer(delimitedLineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);
        return lineMapper;
    }

    @Bean
    public StatusProcessor processor4() {
        return new StatusProcessor();
    }

    @Bean
    public RepositoryItemWriter<Payment> writer4() {
        RepositoryItemWriter<Payment> writer = new RepositoryItemWriter<>();
        writer.setRepository(paymentRepo);
        writer.setMethodName("save");
        return writer;
    }

    @Bean
    public Step step4(FlatFileItemReader<Payment> reader4) {
        return stepBuilderFactory.get("step3").<Payment, Payment>chunk(1003
                )
                .reader(reader4)
                .processor(processor4())
                .writer(writer4())
                .build();
    }

    @Bean("ImportStatus")
    public Job job(FlatFileItemReader<Payment> reader4) {
        return jobBuilderFactory.get("ImportStatus")
                .flow(step4(reader4))
                .end().build();
    }
}
