package com.assignment.paymentmanagementservice.entities;

import com.assignment.paymentmanagementservice.config.AesEncryptor;
import com.assignment.paymentmanagementservice.constants.ErrorMessages;
import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "CUSTOMERS")
@Getter@Setter@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    long customerId;
    @NotBlank
    @Pattern(regexp = "^[A-Za-z\\s]*$", message = ErrorMessages.NAME_VALIDATION)
    String name;
    @Column(unique = true)
    @Pattern(regexp = "^\\d{10}$", message = ErrorMessages.PHONE_NUMBER_VALIDATION)
    @NotBlank
    @Convert(converter = AesEncryptor.class)
    String phoneNumber;
    @Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = ErrorMessages.EMAIL_VALIDATION)
    @Convert(converter = AesEncryptor.class)
    String email;
}