package com.assignment.paymentmanagementservice.dto;

import com.assignment.paymentmanagementservice.constants.OrderStatus;
import com.assignment.paymentmanagementservice.constants.PaymentModes;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)

public class OrderDto {
    long id;
    String orderId;
    CustomerDto customer;
    Double amount;
    PaymentModes paymentMode;
    OrderStatus status = OrderStatus.PENDING;
}
