package com.assignment.paymentmanagementservice.batch.processors;

import com.assignment.paymentmanagementservice.entities.Payment;
import org.springframework.batch.item.ItemProcessor;

public class PaymentItemProcessor implements ItemProcessor<Payment, Payment> {
    @Override
    public Payment process(Payment item) {
        return item;
    }
}
