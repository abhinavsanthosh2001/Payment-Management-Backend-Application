package com.assignment.paymentmanagementservice.batch.processors;

import com.assignment.paymentmanagementservice.constants.OrderStatus;
import com.assignment.paymentmanagementservice.constants.PaymentStatus;
import com.assignment.paymentmanagementservice.entities.Payment;
import com.assignment.paymentmanagementservice.repositories.PaymentRepo;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

public class StatusProcessor implements ItemProcessor<Payment, Payment> {
    @Autowired
    private PaymentRepo paymentRepo;

    @Override
    public Payment process(Payment item) {
        Payment payment = paymentRepo.findByTransactionId(item.getTransactionId());
        payment.setStatus(item.getStatus());
        if (item.getStatus() == PaymentStatus.SUCCESS) {
            payment.getOrder().setStatus(OrderStatus.ORDER_CONFIRMED);
        }
        return payment;
    }
}
