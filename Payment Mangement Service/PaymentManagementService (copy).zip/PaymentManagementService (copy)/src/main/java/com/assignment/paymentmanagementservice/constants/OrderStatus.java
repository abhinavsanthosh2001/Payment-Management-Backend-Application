package com.assignment.paymentmanagementservice.constants;

public enum OrderStatus {
    PENDING,ORDER_CONFIRMED,ORDER_FAILED
}
