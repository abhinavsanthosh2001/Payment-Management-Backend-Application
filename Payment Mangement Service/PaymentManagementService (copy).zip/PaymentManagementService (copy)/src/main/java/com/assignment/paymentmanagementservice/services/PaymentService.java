package com.assignment.paymentmanagementservice.services;

import com.assignment.paymentmanagementservice.config.FileService;
import com.assignment.paymentmanagementservice.constants.ErrorMessages;
import com.assignment.paymentmanagementservice.constants.IdGenerator;
import com.assignment.paymentmanagementservice.constants.OrderStatus;
import com.assignment.paymentmanagementservice.constants.PaymentStatus;
import com.assignment.paymentmanagementservice.dto.PaymentDto;
import com.assignment.paymentmanagementservice.entities.Payment;
import com.assignment.paymentmanagementservice.exceptions.CustomGenericException;
import com.assignment.paymentmanagementservice.payloads.ApiResponse;
import com.assignment.paymentmanagementservice.payloads.PaymentResponse;
import com.assignment.paymentmanagementservice.repositories.OrderRepo;
import com.assignment.paymentmanagementservice.repositories.PaymentRepo;
import com.assignment.paymentmanagementservice.util.EntityDtoConversions;
import com.assignment.paymentmanagementservice.util.Validations;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PaymentService {
    @Autowired
    PaymentRepo paymentRepo;
    @Lazy
    @Autowired
    @Qualifier("Export")
    Job exportJob;
    @Lazy
    @Autowired
    @Qualifier("ImportPayments")
    Job importPaymentsJob;
    @Lazy
    @Autowired
    @Qualifier("ImportStatus")
    Job importStatusJob;
    @Autowired
    IdGenerator idGenerator;
    @Autowired
    OrderRepo orderRepo;
    @Autowired
    Validations validations;
    @Autowired
    EntityDtoConversions entityDtoConversions;
    @Autowired
    JobLauncher jobLauncher;
    @Autowired
    @Qualifier("getTransaction")
    Job getTransactionsJob;
    @Autowired
    FileService fileService;
    static final String TEMP_STORAGE = "/home/Abhinav.Santhosh/Desktop/uploadedFiles/";
    static final String STARTED_AT = "startedAT";


    public void savePayment(PaymentDto payment) {
        payment.setTransactionId(idGenerator.transactionId());
        paymentRepo.save(entityDtoConversions.paymentDtoToEntity(payment));
    }

    public List<PaymentResponse> getPaymentsByOrderId(String orderId) {
        List<PaymentDto> paymentDtos = paymentRepo.findByOrderOrderId(orderId)
                .stream()
                .map(entityDtoConversions::paymentEntityToDto)
                .collect(Collectors.toList());
        List<PaymentResponse> lst = new ArrayList<>();
        for (PaymentDto payment : paymentDtos) {
            lst.add(new PaymentResponse(payment.getOrder().getOrderId(),
                    payment.getTransactionId(),
                    payment.getAmount(),
                    payment.getPaymentMode(),
                    payment.getStatus()));
        }
        validations.validateListOfPayments(lst);
        return lst;
    }

    public ApiResponse updateStatus(String transactionId, PaymentStatus newStatus) {
        Payment payment = getPaymentByTransactionId(transactionId);
        validations.validatePayments(payment);
        PaymentStatus currentStatus = payment.getStatus();
        validations.validatePaymentStatus(currentStatus);
        paymentRepo.updateStatus(payment.getTransactionId(), newStatus.name());
        if (newStatus.ordinal() == 1) {
            orderRepo.updateStatus(OrderStatus.ORDER_CONFIRMED.name(), payment.getOrder().getOrderId());
        }
        return new ApiResponse("Updated Status", "True");

    }

    private Payment getPaymentByTransactionId(String transactionId) {
        return paymentRepo.findByTransactionId(transactionId);
    }

    public void deleteAll() {
        paymentRepo.deleteAll();
    }


    public ResponseEntity<Resource> getBulkTransactions() {
        JobParameters jobParameters = new JobParametersBuilder()
                .addLong(STARTED_AT, System.currentTimeMillis())
                .toJobParameters();
        try {
            jobLauncher.run(getTransactionsJob, jobParameters);
            Resource file = fileService.load("getTransactions.csv");
            return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
                    "attachment;filename=\"" + file.getFilename() + "\"").body(file);
        } catch (JobExecutionAlreadyRunningException | JobParametersInvalidException |
                 JobInstanceAlreadyCompleteException | JobRestartException e) {
            throw new CustomGenericException(ErrorMessages.INTERNAL_SERVER_ERROR_CODE, ErrorMessages.GENERAL + e.getMessage());
        }
    }

    public ResponseEntity<Resource> getBulkStatus() {

        JobParameters jobParameters = new JobParametersBuilder()
                .addLong(STARTED_AT, System.currentTimeMillis())
                .toJobParameters();
        try {
            jobLauncher.run(exportJob, jobParameters);
            Resource file = fileService.load("payments.csv");
            return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
                    "attachment;filename=\"" + file.getFilename() + "\"").body(file);
        } catch (JobExecutionAlreadyRunningException | JobParametersInvalidException |
                 JobInstanceAlreadyCompleteException | JobRestartException e) {
            throw new CustomGenericException(ErrorMessages.INTERNAL_SERVER_ERROR_CODE, e.getMessage());
        }
    }

    public ResponseEntity<ApiResponse> saveBulkPayments(MultipartFile multipartFile) {
        try {
            String originalfilename = multipartFile.getOriginalFilename();
            File fileToImport = new File(TEMP_STORAGE + originalfilename);
            multipartFile.transferTo(fileToImport);
            JobParameters jobParameters = new JobParametersBuilder()
                    .addString("filename", TEMP_STORAGE + originalfilename)
                    .addLong(STARTED_AT, System.currentTimeMillis())
                    .toJobParameters();
            jobLauncher.run(importPaymentsJob, jobParameters);
            return ResponseEntity.ok().body(new ApiResponse("successfully uploaded", "success"));
        } catch (JobExecutionAlreadyRunningException | JobParametersInvalidException |
                 JobInstanceAlreadyCompleteException | JobRestartException|IOException e) {
            throw new CustomGenericException(ErrorMessages.INTERNAL_SERVER_ERROR_CODE, ErrorMessages.GENERAL);
        } catch (Exception e) {
            throw new CustomGenericException(ErrorMessages.INTERNAL_SERVER_ERROR_CODE, ErrorMessages.GENERAL + e.getMessage());
        }
    }

    public ResponseEntity<ApiResponse> updateBulkStatus(MultipartFile multipartFile) {
        try {
            String originalfilename = multipartFile.getOriginalFilename();
            File fileToImport = new File(TEMP_STORAGE + originalfilename);
            multipartFile.transferTo(fileToImport);
            JobParameters jobParameters = new JobParametersBuilder()
                    .addString("filename", TEMP_STORAGE + originalfilename)
                    .addLong(STARTED_AT, System.currentTimeMillis())
                    .toJobParameters();
            jobLauncher.run(importStatusJob, jobParameters);
            return ResponseEntity.ok().body(new ApiResponse("successfully uploaded", "success"));
        } catch (JobExecutionAlreadyRunningException | JobParametersInvalidException | IOException |
                 JobInstanceAlreadyCompleteException | JobRestartException e) {
            throw new CustomGenericException(ErrorMessages.INTERNAL_SERVER_ERROR_CODE, ErrorMessages.GENERAL + e.getMessage());
        }
    }
}

