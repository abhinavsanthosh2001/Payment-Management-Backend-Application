package com.assignment.paymentmanagementservice.batch.processors;

import com.assignment.paymentmanagementservice.constants.IdGenerator;
import com.assignment.paymentmanagementservice.dto.CustomerDto;
import com.assignment.paymentmanagementservice.dto.OrderDto;
import com.assignment.paymentmanagementservice.entities.Payment;
import com.assignment.paymentmanagementservice.repositories.OrderRepo;
import com.assignment.paymentmanagementservice.services.CustomerService;
import com.assignment.paymentmanagementservice.util.EntityDtoConversions;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class PaymentProcessor implements ItemProcessor<Payment, Payment> {
    @Autowired
    IdGenerator idGenerator;
    @Autowired
    CustomerService customerService;
    @Autowired
    OrderRepo orderRepo;
    @Autowired
    EntityDtoConversions entityDtoConversions;

    @Override
    public Payment process(Payment item) {

        item.getOrder().setAmount(item.getAmount());
        item.getOrder().setPaymentMode(item.getPaymentMode());
        CustomerDto customerDto = customerService.saveCustomer(entityDtoConversions.customerEntityToDto(item.getOrder().getCustomer()));
        item.getOrder().setCustomer(entityDtoConversions.customerDtoToEntity(customerDto));
        item.getOrder().setOrderId(idGenerator.orderId());
        OrderDto orderDto = entityDtoConversions.orderEntityToDto(orderRepo.save(item.getOrder()));
        item.setOrder(entityDtoConversions.orderDtoToEntity(orderDto));
        item.setTransactionId(idGenerator.transactionId());
        return item;
    }
}
