package com.assignment.paymentmanagementservice.constants;

public enum PaymentModes {
    DEBITCARD,CREDITCARD,UPI,NETBANKING,COD
}
