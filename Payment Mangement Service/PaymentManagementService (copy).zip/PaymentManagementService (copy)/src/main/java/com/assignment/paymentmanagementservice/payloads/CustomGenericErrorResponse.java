package com.assignment.paymentmanagementservice.payloads;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomGenericErrorResponse {
    private String errorCode;
    private String message;
}
