package com.assignment.paymentmanagementservice.batch.configurations;

import com.assignment.paymentmanagementservice.batch.processors.PaymentProcessor;
import com.assignment.paymentmanagementservice.entities.Payment;
import com.assignment.paymentmanagementservice.repositories.PaymentRepo;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import java.io.File;

@EnableBatchProcessing
@Configuration
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequiredArgsConstructor
public class PaymentsDump {
    JobBuilderFactory jobBuilderFactory;
    StepBuilderFactory stepBuilderFactory;
    PaymentRepo paymentRepo;


    @Bean
    @StepScope
    public FlatFileItemReader<Payment> reader6(@Value("#{jobParameters[filename]}") String pathToFile) {
        FlatFileItemReader<Payment> itemReader = new FlatFileItemReader<>();
        itemReader.setResource(new FileSystemResource(new File(pathToFile)));
        itemReader.setName("CsvReader");
        itemReader.setLinesToSkip(1);
        itemReader.setLineMapper(lineMapper6());
        return itemReader;
    }

    private LineMapper<Payment> lineMapper6() {
        DefaultLineMapper<Payment> lineMapper = new DefaultLineMapper<>();

        DelimitedLineTokenizer delimitedLineTokenizer = new DelimitedLineTokenizer();
        delimitedLineTokenizer.setDelimiter(",");
        delimitedLineTokenizer.setStrict(false);
        delimitedLineTokenizer.setNames("amount", "paymentMode", "order.customer.name", "order.customer.phoneNumber", "order.customer.email");

        BeanWrapperFieldSetMapper<Payment> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(Payment.class);

        lineMapper.setLineTokenizer(delimitedLineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);
        return lineMapper;
    }

    @Bean
    public PaymentProcessor processor6() {

        return new PaymentProcessor();
    }

    @Bean
    public RepositoryItemWriter<Payment> writer6() {
        RepositoryItemWriter<Payment> writer = new RepositoryItemWriter<>();
        writer.setRepository(paymentRepo);
        writer.setMethodName("save");
        return writer;
    }

    @Bean
    public Step step6(FlatFileItemReader<Payment> reader6) {
        return stepBuilderFactory.get("step6").<Payment, Payment>chunk(200)
                .reader(reader6)
                .processor(processor6())
                .writer(writer6())
                .build();
    }

    @Bean("ImportPayments")
    public Job job(FlatFileItemReader<Payment> reader6) {
        return jobBuilderFactory.get("ImportPayments")
                .flow(step6(reader6))
                .end().build();
    }
}
