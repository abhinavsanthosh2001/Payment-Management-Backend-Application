package com.assignment.paymentmanagementservice.controllers;

import com.assignment.paymentmanagementservice.constants.PaymentStatus;
import com.assignment.paymentmanagementservice.payloads.ApiResponse;
import com.assignment.paymentmanagementservice.payloads.PaymentResponse;
import com.assignment.paymentmanagementservice.services.PaymentService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping(value = "/payment")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequiredArgsConstructor
public class PaymentController {
    PaymentService paymentService;

    @GetMapping("/{orderId}")
    public ResponseEntity<List<PaymentResponse>> getPayments(@PathVariable("orderId") String orderId) {
        return ResponseEntity.ok().body(paymentService.getPaymentsByOrderId(orderId));
    }

    @PutMapping("/StatusUpdate/{transactionId}/{status}")
    public ResponseEntity<Object> updateStatus(@PathVariable("transactionId") String transactionId,
                                               @PathVariable("status") PaymentStatus status) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(paymentService.updateStatus(transactionId, status));
    }

    @GetMapping("/getStatus")
    public ResponseEntity<Resource> getPaymentStatus() {
        return paymentService.getBulkStatus();
    }

    @PutMapping("/dumpStatus")
    public ResponseEntity<ApiResponse> updateBulkStatus(@RequestParam("file") MultipartFile multipartFile) {
        return paymentService.updateBulkStatus(multipartFile);
    }

    @PostMapping("/dump")
    public ResponseEntity<ApiResponse> savePayments(@RequestParam("file") MultipartFile multipartFile) {
        return paymentService.saveBulkPayments(multipartFile);
    }

    @GetMapping("/getTransactions")
    public ResponseEntity<Resource> getTransactions() {
        return paymentService.getBulkTransactions();
    }
}
