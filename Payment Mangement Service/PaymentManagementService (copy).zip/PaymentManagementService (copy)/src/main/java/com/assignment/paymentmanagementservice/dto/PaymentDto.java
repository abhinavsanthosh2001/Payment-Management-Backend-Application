package com.assignment.paymentmanagementservice.dto;

import com.assignment.paymentmanagementservice.constants.PaymentModes;
import com.assignment.paymentmanagementservice.constants.PaymentStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)

public class PaymentDto {
    long Id;
    String transactionId;
    double amount;
    PaymentStatus status = PaymentStatus.PENDING;
    OrderDto order;
    PaymentModes paymentMode;
}
