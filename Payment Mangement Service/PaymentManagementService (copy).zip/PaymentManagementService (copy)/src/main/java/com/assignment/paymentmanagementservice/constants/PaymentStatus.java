package com.assignment.paymentmanagementservice.constants;

public enum PaymentStatus {
    PENDING,SUCCESS,FAILURE,
}
